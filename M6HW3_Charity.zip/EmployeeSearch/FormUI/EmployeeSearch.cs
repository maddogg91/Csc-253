﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* December 8th
* CSC 253
* Robert Charity II
* Employee Search
* This program allows users to search the employee table by First Name, Last name, or Both.
*/



namespace FormUI
{
    public partial class EmployeeSearch : Form
    {
        string firstName, lastName;

        public EmployeeSearch()
        {
            
            InitializeComponent();
        }

        private void tableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDBDataSet);

        }

        private void EmployeeSearch_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDBDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.personnelDBDataSet.Table);

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            firstName = textBox2.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

            if (firstName == null && lastName == null)
            {
                MessageBox.Show("Enter employee name");
            }

            if (firstName != null && lastName != null)
            {
                tableTableAdapter.SearchFullName(personnelDBDataSet.Table, firstName, lastName);
            }

            if (firstName != null && lastName == null)
            {

                tableTableAdapter.SearchByFirstName(personnelDBDataSet.Table, firstName);   

            }

            if (lastName != null && firstName == null)
            {

                tableTableAdapter.SearchByLastName(personnelDBDataSet.Table, lastName);
            }

            if (lastName == "*" || firstName == "*")
            {
                this.tableTableAdapter.Fill(this.personnelDBDataSet.Table);
            }
            textBox1.Text = null;
            textBox2.Text = null;
            firstName = null;
            lastName = null;


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            lastName = textBox1.Text;
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRLibrary;

namespace ConsoleUI
{
/**
* November 19th 2019
* CSC 253
* Robert Charity
* Employee_Class_Console
* This program stores employee objects and displays the data upon request.
*/
    class Program
    {
       
        static void Main(string[] args)
        {
            StandardMessages standardMessages = new StandardMessages();

            //Boolean format for exit
            bool exit = false;

            //Runs until case 2 is chosen.
            do
            {
                //Displays Menu messages
                standardMessages.DisplayText(standardMessages.Menu());

                //Receives input from Menu
                string input = Console.ReadLine();

             


                switch (input)
                {
                    //If 1 is entered the store data display starting with Susan, Mark, and then Joy.
                    case "1":

                        //Calls Output from standard messages

                        standardMessages.DisplayText(standardMessages.EmployeeOutput(Roster.Susan())+ "\n"
                           + standardMessages.EmployeeOutput(Roster.Mark()) + "\n"
                           + standardMessages.EmployeeOutput(Roster.Joy()));
                        
                        
                        break;

                     //If 2 is entered the program exits.
                    case "2":
                        exit = true;
                        break;

                    //Anything else entered will return an error.
                    default:
                        standardMessages.DisplayText(standardMessages.Error());
                        break;

                }


            } while (exit == false);
            
          
           
            
          





        }
        
    }
}

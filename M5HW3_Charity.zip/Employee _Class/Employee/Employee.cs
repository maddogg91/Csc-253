﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLibrary
{
    //Employee Object Definition
    public class Employee
    {

        public string Name { get; set; }
        public int IdNumber { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }

        //Employee constructor
        public Employee(string name, int idnumber, string department, string position)
        {
            Name = name;
            IdNumber = idnumber;
            Department = department;
            Position = position;

        }

        //Gets information from Roster Class

        public static Employee GetInfo(Employee employee)
        {
            return employee;
        }


        //Creates a default employee when called
        public static Employee DefaultEmployee()
        {
            Employee employee= new Employee("", 0, "", "");
            return employee;
        }

        


    }
}

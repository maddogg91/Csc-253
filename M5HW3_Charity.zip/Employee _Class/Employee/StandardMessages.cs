﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace HRLibrary
{
    
    public class StandardMessages
    {
        public void DisplayText(string text)
        {
            Console.WriteLine(text);
        }
        
        //Displays Menu
        public string Menu()
        {
            
            {
                return $"1. Display Employees\n" +
                "2. Exit";
            }
         
        }

        //Displays Employee information

        public string EmployeeOutput(Employee employee)
        {
            string t1 = "Name".PadLeft(10);
            string t2 = "ID".PadLeft(20);
            string t3 = "Department".PadLeft(25);
            string t4 = "Position".PadLeft(30);

            {
                return $"{t1}{t2}{t3}{t4}" +
                    $"\n--------------------------------------------------------------------------------------------" +
                    $"\n{employee.Name} {employee.IdNumber.ToString().PadLeft(15)} {employee.Department.PadLeft(20)} {employee.Position.PadLeft(32)}\n";
               }   
    
        }

        //Displays error
        public string Error()
        {
           
            return
            $"\nError: Invalid entry";
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLibrary

{
    
    public class Roster
    {
        //Roster space for Susan
        public static Employee Susan()
        {
            Employee Susan = new Employee("Susan Myers", 47899, "Accounting", "Vice President");
            return Susan;

        }
        //Roster space for Mark
        public static Employee Mark()
        {
            Employee Mark = new Employee("Mark Jones", 39119, "IT", "Programmer");
            return Mark;
        }
        //Roster space for Joy
        public static Employee Joy()
        {
            Employee Joy = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
            return Joy;
        }

    }



}

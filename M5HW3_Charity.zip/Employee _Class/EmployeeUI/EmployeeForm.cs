﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HRLibrary;

namespace EmployeeUI
{
    //Applies the same principles as Console but uses a form to display information
    public partial class EmployeeForm : Form
    {
        StandardMessages sm = new StandardMessages();
        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(sm.EmployeeOutput(Roster.Susan()));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(sm.EmployeeOutput(Roster.Joy()));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(sm.EmployeeOutput(Roster.Mark()));
        }
    }
}

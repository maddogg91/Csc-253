﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using ConsoleUI;



namespace TestLibrary.Tests
{
    [TestFixture]
    public class RetailPriceTests
    {

        //Unit Test #1 from the Book

        [Test]
        public void PercentageMarkupCalculationTestProblem1()
        {
            //Arrange
            decimal x = 5;
            decimal y = 1;
            decimal expected = 10;


            // Act 
            decimal actual = RetailCalculation.CalculateRetail(x, y);

            //Assert
            Assert.AreEqual(actual, expected);

        }

        //Unit Test #2 from the Book

        [Test]
        public void PercentageMarkupCalculationTestProblem2()
        {
            //Arrange
            decimal x = 5;
            decimal y = .5m;
            decimal expected = 7.50m; 


            // Act 
            decimal actual = RetailCalculation.CalculateRetail(x, y);

            //Assert
            Assert.AreEqual(actual, expected);
            
        }


        //Test case fail

        [Test]
        public void PercentageMarkupCalculationTestFail()
        {
            //Arrange
            decimal x = 1;
            decimal y = 1;
            decimal fail = 4;


            // Act 
            decimal actual = RetailCalculation.CalculateRetail(x, y);

            //Assert
            Assert.AreEqual(actual, fail);

        }
    }
}

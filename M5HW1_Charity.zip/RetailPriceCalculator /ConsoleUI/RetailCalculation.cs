﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/**
* November 10th, 2019
* CSC 253
* Robert Charity II
* RetailPriceCalculator w/ Unit Testing
* Receives the wholesale cost and the markup percentage as arguments 
* and returns the retail price of the item. **ADDED Unit Testing***
*/

namespace ConsoleUI
{
    public class RetailCalculation
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"The retail price for this item is : {DisplayRetailCost()}");
            Console.ReadLine();
        }

        public static decimal CalculateRetail(decimal x, decimal y)
        {
          

            return ((x * y) + x);
        }


        private static string DisplayRetailCost()
        {
            return CalculateRetail(getWholeSaleCost(), getMarkUpPercentage()).ToString("C2");

        }

        private static decimal getMarkUpPercentage()
        {
            Console.Write($"\nPlease enter the markup percentage\n>");
            string input = Console.ReadLine();
            decimal cost = 0;
            try
            {
                cost = decimal.Parse(input);
            }

            catch
            {
                getWholeSaleCost();
            }

            cost = cost / 100;
            return cost;
        }

        private static decimal getWholeSaleCost()
        {
            Console.Write($"\nPlease enter the item's whole sale cost\n>");
            string input = Console.ReadLine();
            decimal cost = 0;
            try
            {
                cost = decimal.Parse(input);
            }

            catch
            {
                getWholeSaleCost();
            }
           
            return cost;
        }
    }
}

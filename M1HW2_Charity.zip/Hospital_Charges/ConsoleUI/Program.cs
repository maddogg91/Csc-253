﻿using System;

namespace ConsoleUI
{
    /**
  * September 1, 2019
  * CSC 253
  * Robert Charity
  * Hospital Charges
  * Calculates the total cost of hospital stay.
*/
    class Program
    {
        static void Main(string[] args)
        {
            DisplayMenu();
        }
        public static void DisplayMenu()
        {
            //Controls for Menu function
            bool run = true;
            bool exit = false;
            //Main menu
            while (run == true)
            {

                Console.WriteLine("This program will display the total cost of a hospital stay.");
                Console.WriteLine("\nWould you like to run this program?");
                Console.Write("Enter yes or no > ");
                string input = Console.ReadLine();
                switch (input)
                {
                    //if yes, the program runs
                    case "yes":
                        exit = false;
                        run = false;
                        break;


                    //if no, the program closes
                    case "no":
                        exit = true;
                        run = false;
                        break;

                    default:
                        Console.WriteLine("Invalid selection");
                        Console.ReadLine();
                        break;

                }

            }
            while (exit == false)
            {


                //Display Main Menu
                Console.WriteLine("\nWelcome to the main menu:\n\n\n\n\nChoose an option below:\n1. Run Program\n2.Exit ");
                Console.Write("Enter your option:>");
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":

                        decimal hospitalCost = CalcTotalCharges();
                        Console.WriteLine("The total cost for the hospital stay is: " + hospitalCost.ToString("C"));
                        Console.ReadLine();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("\nEnter valid response");
                        break;



                }
            }
        }
        //Gets the amount of days from user
        public static int GetDays()
        {
            bool run = false;
            int days = 0;
            while (run == false)
            {
                Console.Write("\nHow many days did the patient stay?\n>");
                string input = Console.ReadLine();
                if (int.TryParse(input, out days))
                {
                    if (days > 0)
                    {
                        Console.WriteLine("\nYou've entered: " + days + " days");
                        run = true;
                    }
                    else
                    {
                        Console.WriteLine("\nError: Please enter a value greater than 0");
                    }
                }

                else
                {
                    Console.WriteLine("\nError: Please enter an interger");
                }
            }
           
            return days;
        }

        //Asks user for Medication cost
        public static decimal GetMedicationCharges()
        {
            bool run = false;
            decimal medication = 0;
            while (run == false)
            {
                Console.Write("\nHow much was the medication?\n>$");
                string input = Console.ReadLine();
                if (decimal.TryParse(input, out medication))
                {
                    if (medication < 0)
                    {
                        Console.WriteLine("\nError: Please enter a value greater than or equal to 0");
                    }
                    else
                    {
                        run = true;
                    }
                }

                else
                {
                    Console.WriteLine("\nError: Please enter an interger");
                }
            }
           
            return medication;
        }

        //Asks user for Surgerical cost
        public static decimal GetSurgicalCost()
        {
            bool run = false;
            decimal surgery = 0;
            while (run == false)
            {
                Console.Write("\nHow much was the surgery charges?\n>$");
                string input = Console.ReadLine();
                if (decimal.TryParse(input, out surgery))
                {
                    if (surgery < 0)
                    {
                        Console.WriteLine("\nError: Please enter a value greater than or equal to0");
                    }
                    else
                    {
                        run = true;
                    }
                }

                else
                {
                    Console.WriteLine("\nError: Please enter an interger");
                }
            }
          
            return surgery;
        }

        //Asks user for Lab cost
        public static decimal GetLabFees()
        {
            bool run = false;
            decimal lab = 0;
            while (run == false)

            {
                Console.Write("\nHow much was the lab charges?\n>$");
                string input = Console.ReadLine();
                if (decimal.TryParse(input, out  lab))
                {
                    if (lab < 0)
                    {
                        Console.WriteLine("\nError: Please enter a value greater than or equal to 0");
                    }
                    else
                    {
                        run = true;
                    }
                }

                else
                {
                    Console.WriteLine("\nError: Please enter an interger");
                }

            }
           
            return lab;
        }

        //Asks user for Rehab cost
        public static decimal GetRehabFees()
        {
            bool run = false;
            decimal rehab = 0;
            while (run == false)
            {
                Console.Write("\nHow much was the charges for physical rehab?\n>$");
                string input = Console.ReadLine();
                if (decimal.TryParse(input, out rehab))
                {
                    if (rehab < 0)
                    {
                        Console.WriteLine("\nError: Please enter a value greater than or equal to 0");
                    }
                    else
                    {
                        run = true;
                    }
                }

                else
                {
                    Console.WriteLine("\nError: Please enter an interger");
                }
            }
            
            return rehab;
        }

        //Calculates the base charge
        public static decimal CalcStayCharges()
        {

            int days = GetDays();
            decimal baseCharges = days * 350m;
            return baseCharges;
        }

        //Calculates hospital misc charges
        public static decimal CalcMiscCharges()
        {
            
            decimal medication = GetMedicationCharges();
            decimal surgical = GetSurgicalCost();
            decimal lab = GetLabFees();
            decimal rehab = GetRehabFees();
            decimal total = medication + surgical + lab + rehab;
            return total;
        }

        //Calculates the total charges
        public static decimal CalcTotalCharges()
        {
            decimal baseCharges = CalcStayCharges();
            decimal miscCharges = CalcMiscCharges();
            decimal total = baseCharges + miscCharges;
            return total;
        }



    }
}

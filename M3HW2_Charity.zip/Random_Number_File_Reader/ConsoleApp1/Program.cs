﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleUI
{

    /**
    * September 29th, 2019
    * CSC 253
    * Robert Charity II
    * Random Number File Reader
    * This program reads random numbers from the random.txt file.
*/
    class Program
    {
        static void Main(string[] args)
        {
            Reader();
        }
        static void Reader()
        {
            StreamReader inputFile;
            
            try
            {
                inputFile = File.OpenText("random.txt");
                GetTotal(inputFile);
                inputFile.Close();

               

            }
            
            catch
            {
                Console.WriteLine("This file does not exist");
                Console.ReadLine();
            }
           

        }

        static void GetTotal(StreamReader inputFile)
        {
            int total = 0;
            int i = 0;
            while (!inputFile.EndOfStream)
            {
                string input = inputFile.ReadLine();
                try
                {
                    
                    int number= int.Parse(input);
                    total = total + number;
                    i++;
                }

                catch (FormatException)
                {

                }

               
            }
            DisplayTotal(total);
            DisplayNumberofRandom(i);
            Console.ReadLine();
        }

        static void DisplayTotal(int total)
        {
            Console.WriteLine("The added total amount in this file is: " + total.ToString());
            
        }

        static void DisplayNumberofRandom(int i)
        {
            Console.WriteLine("The number of random numbers in this file is: " + i.ToString());
        }
    }
}

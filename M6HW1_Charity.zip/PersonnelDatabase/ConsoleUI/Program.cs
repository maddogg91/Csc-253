﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonnelDBForm;

/*
 * December 8th, 2019
 * CSC 253
 * Robert Charity II
 * This application displays Employee information in a Database
 */

namespace ConsoleUI
{
   
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Would you like to view the employee information?\nEnter yes to view data >");
            switch (Console.ReadLine().ToLower())
            {
                case "yes":
                    Form1 page = new Form1();
                    page.ShowDialog();
                    break;

                default:

                    break;
            }
        }
    }
}

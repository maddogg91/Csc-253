﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CharacterLibrary;
using OptionsLibrary;
using ItemLibrary;


namespace Streets_Of_Malice
{/**

* November 5th, 2019

* CSC 253

* Jesse Watts 
* 
* Robert Charity

* Streets of Malice (Sprint #3)
* 
* Streets of Malice is an urban inspired dungeon crawler. 
*
* This build adds interfaces, a combat class, and mobs that move around.

*/
    class Program
    {

        static void Main(string[] args)
        {
            GameOptions.Startup();


           
        }
        




     

        

        


        //Contains methods for user inputs
        

        //Determines where the user moves when certain directions are added in
        
        

    }
}

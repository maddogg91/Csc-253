﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterfaceLibrary
{
    public interface ICombatant
    {
        string Name
        {
            get;set;
        }
        int HP
        {
            get; set;
        }

        int Attack

        {
            get; set;
        }

        
    }
}

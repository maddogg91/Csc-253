﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterfaceLibrary
{
    public interface IEnvironment
    {


        string ID
        {
            get;set;  
        }

        string Name
       
            {
                get; set;
            }
       
        string Description
        {
            get; set;
        }
        
            
    }
}

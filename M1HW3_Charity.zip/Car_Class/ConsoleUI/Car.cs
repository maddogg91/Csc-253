﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{


    //Car Class
    class Car
    {
        //Properties for Car
        private int _year;
        private string _make;
        private int _speed;
      
        //Constructors
        public Car(string make, int year)
        {
            _year = year;
            _make = make;
            _speed = 0;
           
        }

        //Make Property
        public string Make
        {
            get { return _make; }
            set { _make = value; }

        }

        //Year Property
        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        //When called, Car's speed increases by 5.
        public void Accelerate()
        {
            _speed += 5;
            Console.WriteLine("\nThe " + _year + " " + _make + " sped up to " + _speed + "MPH");

        }

        //When called, Car's speed decreases by 5, unless car is completely stopped already.
        public void Brake()
        {
            if (_speed <= 0)
            {
                Console.WriteLine("\nThe " + _year + " " + _make + " is currently not moving.");
            }

            else
            {
                _speed += -5;
                if (_speed == 0)
                {
                    Console.WriteLine("\nThe " + _year + " " + _make + " has slowed down completely and stopped");
                }
                else
                {
                    Console.WriteLine("\nThe " + _year + " " + _make + " slowed down to " + _speed + "MPH");
                }
                

               
            }
        }



    }
}

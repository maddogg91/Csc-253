﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleUI
{
    /**
   * September 1, 2019
   * CSC 253
   * Robert Charity
   * Car Class
   * This program allows a user to create a car, then allows the user to test acceleration and braking functions.
*/
    class Program
    {
        static void Main(string[] args)
        {
            //Displays the initial menu
            DisplayMenu();
        }
        public static void DisplayMenu()
        {
            //Controls for Menu function
            bool run = true;
            bool exit = false;
            //Main menu
            while (run == true)
            {

                Console.WriteLine("This program allow you to create a car and use it to accelerate or brake.");
                Console.WriteLine("\nWould you like to run this program?");
                Console.Write("Enter yes or no > ");
                string input = Console.ReadLine();
                switch (input)
                {
                    //if yes, the program runs
                    case "yes":
                        exit = false;
                        run = false;
                        break;


                    //if no, the program closes
                    case "no":
                        exit = true;
                        run = false;
                        break;

                    default:
                        Console.WriteLine("Invalid selection");
                        Console.ReadLine();
                        break;

                }

            }
            while (exit == false)
            {

                
                //Display Main Menu
                Console.WriteLine("\nWelcome to the main menu:\n\n\n\n\nChoose an option below:\n1. Create A Car\n2.Exit ");
                Console.WriteLine("Enter your option:>");
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        //Creates a new car using the Car class
                        Car car= MakeNewCar();
                        bool driving = true;
                        while (driving == true)
                        {
                            //Displays Driving Menu after Car is created
                            Console.WriteLine("\n\n\n\n\n\nChoose an option below:\n1. Accelerate\n2.Brake\n3.Back to Main Menu ");
                            string response = Console.ReadLine();
                            switch (response)
                            {
                                case "1":
                                    car.Accelerate();
                                    break;
                                case "2":
                                    car.Brake();
                                    break;
                                case "3":
                                    Console.WriteLine("\nCar comes to a complete stop! Returning to Main Menu");
                                    driving = false;
                                    break;
                                default:
                                    Console.WriteLine("\nEnter valid response");
                                    break;

                            }
                        }
             
                        Console.ReadLine();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("\nEnter valid response");
                        break;



                }
            }
        }

        //Method asks for user input while Car class is being utilized.
        public static Car MakeNewCar()
        {
            int year = 0;
            bool run = false;
            while (run == false)
            {
               
                Console.WriteLine("\nWhat is the year of the Car?");
                string input = Console.ReadLine();
                if (int.TryParse(input, out year))
                {
                    if (year > 1900 && year < 2020)
                    {
                        Console.WriteLine("\nYou've entered: " + year);
                        run = true;
                    }
                    else
                    {
                        Console.WriteLine("\nError: Please enter a year between 1900 and 2020");
                    }
                }

                else
                {
                    Console.WriteLine("\nError: Please enter a valid year");
                }

            }

            Console.WriteLine("\nWhat is the make of the car?");
            string make = Console.ReadLine();

            //Creates the car using the inputted information
            Car car = new Car(make, year);
            return car;
        }
    }

   
}

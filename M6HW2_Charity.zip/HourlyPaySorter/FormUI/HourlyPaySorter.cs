﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{


    /**
    * December 6th 2019
    * CSC 253
    * Robert Charity II
    * Hourly Pay Sorter
    * This form adds two order by buttons to sort data by the hourly pay rate.
    */


    public partial class HourlyPaySorter : Form
    {
        public HourlyPaySorter()
        {
            InitializeComponent();
        }

        private void tableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDBDataSet);

        }

        private void HourlyPaySorter_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDBDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.personnelDBDataSet.Table);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tableTableAdapter.OrderAsc(personnelDBDataSet.Table);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tableTableAdapter.OrderDesc(personnelDBDataSet.Table);
        }
    }
}

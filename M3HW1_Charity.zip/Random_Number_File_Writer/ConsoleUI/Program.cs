﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace ConsoleUI
{

    /**
    * September 29th, 2019
    * CSC 253
    * Robert Charity II
    * Random Number File Writer
    * This program generates random numbers and saves them to a text file.
*/
    class Program
    {
        static void Main(string[] args)
        {

            Menu();
           
        }

        static void Menu()
        {
            Console.WriteLine("This program generates random numbers to a text file named 'random.txt'. \nWould you like to run this program?");
            Console.Write(">");
            string input = Console.ReadLine();
            switch (input.ToLower())
            {
                case "yes":
                case "y":
                    Console.WriteLine("\n");
                    GetAmount();
                    Console.WriteLine("\nFile has been saved!\n");
                    Menu();
                    break;
                case "no":
                case "n":
                    break;
                default:
                    Console.WriteLine("Error: Please enter yes or no");
                    Console.WriteLine("\n");
                    Menu();
                    break;

            }
        }

        static void GetAmount()
        {
            Console.WriteLine("How many random numbers do you want to generate?");
            string input = Console.ReadLine();
            try
            {
                int amount= int.Parse(input);
                if (amount <= 0)
                {
                    Console.WriteLine("\nPlease enter more than 0 in order to generate a file\n");
                    GetAmount();
                }

                else
                {
                    CreateRandomNumbers(amount);
                }

            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid entry! Please enter a number greater than 0.\n");
                GetAmount();
            }
        }

        static void CreateRandomNumbers(int amount)
        {
            Random rand = new Random();
            StreamWriter outputFile;
            outputFile = File.CreateText("random.txt");
            outputFile.Close();
            
            for (int x= 0; amount > x; x++)
            {
                int number = rand.Next(0, 100);
                FileWriter(number, outputFile);
            }
        }



        static void FileWriter(int number, StreamWriter outputFile)
        {
            
            outputFile = File.AppendText("random.txt");
            outputFile.WriteLine(number.ToString());
            outputFile.Close();
        }
    }
}

﻿using System;

namespace ConsoleUI
{
    /**
  * September 1, 2019
  * CSC 253
  * Robert Charity
  * RetailItem Class
  * This program creates arrays of items held within the RetailItem class and displays them.
*/
    class Program
    {
        static void Main(string[] args)
        {
            //Displays the initial menu
            DisplayMenu();
        }

        public static void DisplayMenu()
        {
            //Controls for Menu function
            bool run = true;
            bool exit = false;
            //Main menu
            while (run == true)
            {

                Console.WriteLine("This program create an array of items in a retail store and display them.");
                Console.WriteLine("\nWould you like to run this program?");
                Console.Write("Enter yes or no > ");
                string input = Console.ReadLine();
                switch (input)
                {
                    //if yes, the program runs
                    case "yes":
                        exit = false;
                        run = false;
                        break;


                    //if no, the program closes
                    case "no":
                        exit = true;
                        run = false;
                        break;

                    default:
                        Console.WriteLine("Invalid selection");
                        Console.ReadLine();
                        break;

                }

            }
            while (exit == false)
            {


                //Display Main Menu
                Console.WriteLine("\nWelcome to the main menu:\n\n\n\n\nChoose an option below:\n1.Display Retail Items\n2.Exit ");
                Console.WriteLine("Enter your option:>");
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        SetItems();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("\nEnter valid response");
                        break;



                }
            }
        }
      
        public RetailItem[] items = new RetailItem[3];


        //Creates the three objects and puts them into an array
        public static void SetItems()
        {
            RetailItem item1 = new RetailItem("Jacket", 12, 59.95m);
            RetailItem item2 = new RetailItem("Jeans", 40, 34.95m);
            RetailItem item3 = new RetailItem("Shirt", 20, 24.95m);
            RetailItem[] items = { item1, item2, item3 };
            DisplayItems(items);
        }

        //For Loop to Display all the intems in the array
        public static void DisplayItems(RetailItem[] items)
        {
            
            for (int i = 0; i < items.Length; i++)
            {
                Console.WriteLine("\nItem #" + (i + 1) + "\nDescription: " + items[i]._description + "\nUnits on Hand: " + items[i]._unitsOnHand
                    + "\nPrice: " + items[i]._price.ToString("C"));

            }
            Console.ReadLine();
        }


    }

}

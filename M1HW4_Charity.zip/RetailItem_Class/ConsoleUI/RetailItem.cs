﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleUI
{
    class RetailItem
    {
        public string _description;
        public int _unitsOnHand;
        public decimal _price;

        public RetailItem(string Description, int UnitsOnHand, decimal Price)
        {
            _description = Description;
            _unitsOnHand = UnitsOnHand;
            _price = Price;
        }

        


       
    }
}

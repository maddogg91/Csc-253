﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleUI;
using NUnit.Framework;

namespace TuitionIncrease.Tests
{
    [TestFixture]
    public class TuitionIncreaseTest
    {
        [Test]

        public void TuitionIncreaseTestProblem_After1Year()
        {
            decimal x = 6000m;
            decimal y = .02m;
            int z = 1;
            decimal expected = 6120m;

            decimal actual= Program.getTuitionIncrease(x, y, z);

            Assert.AreEqual(actual, expected);
               

        }
        [Test]
        public void TuitionIncreaseTestProblem_After5Years()
        {
            decimal x = 6000m;
            decimal y = .02m;
            int z = 5;
            decimal expected = 6624.48m;

            decimal actual = Program.getTuitionIncrease(x, y, z);

            Assert.AreEqual(actual, expected);


        }
    }
}

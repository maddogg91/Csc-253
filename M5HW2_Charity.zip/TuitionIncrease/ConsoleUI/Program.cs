﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




/**
* November 10th, 2019
* CSC 253
* Robert Charity II
* This program tests tuition increase from a starting amount of 6000 over five years. 
*/

namespace ConsoleUI
{
    public class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i <= 5)
            {
                switch (i)
                {
                    case 0:
                        Console.WriteLine($"The starting tuition is $6000" +
                  $" per semester.");
                        break;

                    case 1:
                        Console.WriteLine($"\nAfter the first year the tuition will be {getTuitionIncrease(6000m, .02m, i).ToString()}" +
                  $" per semester.");
                        break;

                    default:
                        Console.WriteLine($"\nAfter {i} years the tuition will be {getTuitionIncrease(6000m, .02m, i).ToString()}" +
                   $" per semester.");
                        break;

                }
                i++;
            }
            Console.ReadLine();

           
        }
        

        

        public static decimal getTuitionIncrease(decimal x, decimal y, int z)
        {
           
            decimal tuition = 0;
            decimal initialTuition = x;
            for (int i= 0 ; z >  i; i++)
            {
                if (i == 0)
                {
                    tuition = (initialTuition * y) + initialTuition;
                }

                else
                {
                    tuition = (tuition * y) + tuition;
                }
               

                x = Math.Round(tuition, 2, MidpointRounding.ToEven);
                
            }
               
                
            

            return x;
        }
    }
}

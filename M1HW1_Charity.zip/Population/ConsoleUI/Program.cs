﻿using System;

namespace ConsoleUI
{
    /**
    * August 31, 2019
    * CSC 253
    * Robert Charity
    * Population
    * This program predicts the approximate size of a population of organisms
*/
    class Program
    {
        static void Main(string[] args)
        {
            //Displays the initial menu
            DisplayMenu();
        }

        public static void DisplayMenu()
        {
            //Controls for Menu function
            bool run = true;
            bool exit = false;
            //Main menu
            while (run == true)
            {
                
                Console.WriteLine("This program will predict the approximate size of a population of organisms.");
                Console.WriteLine("\nWould you like to run this program?");
                Console.Write("Enter yes or no > ");
                string input = Console.ReadLine();
                switch (input)
                {
                    //if yes, the program runs
                    case "yes":
                        exit = false;
                        run = false;
                        break;


                    //if no, the program closes
                    case "no":
                        exit = true;
                        run = false;
                        break;

                    default:
                        Console.WriteLine("Invalid selection");
                        Console.ReadLine();
                        break;

                }

            }
            while (exit == false)
            {


                //Display Main Menu
                Console.WriteLine("\nWelcome to the main menu:\n\n\n\n\nChoose an option below:\n1. Run Program\n2.Exit ");
                Console.WriteLine("Enter your option:>");
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":

                        DisplayTotal();
                        Console.ReadLine();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("\nEnter valid response");
                        break;

           

                }
            }
        }
        //Gets input from user for Organisms
        public static int GetOrganisms()
        {
            int organisms=0;
            bool run = false;


            while(run == false)
            {
                Console.WriteLine("\nWhat is the starting number of organisms?\n>");
                string input = Console.ReadLine();
                if (int.TryParse(input, out organisms))
                {
                    if (organisms > 0)
                    {
                        Console.WriteLine("\nYou've entered: " + organisms + " organisms");
                        run = true;
                    }
                    else
                    {
                        Console.WriteLine("\nError: Please enter a value greater than 0");
                    }
                }

                else
                {
                    Console.WriteLine("\nError: Please enter an interger");
                }
                
            }
            return organisms;
        }

        //Sets value for organism into a decimal
        public static decimal SetOrganisms()
        {
            decimal organisms = GetOrganisms();
            return organisms;

        }

        //Calculates the daily average when called
        public static decimal CalculateDailyAverage(decimal organisms)
        {
            
            decimal average = .30M;
            decimal increase = organisms * average;
            decimal population = increase + organisms;
            
            
            return population;
     


        }

        //Gets user input for the amount of days
        public static int GetDays()
        {
            int days = 0;
            bool run = false;
            while (run== false)
            {
                Console.WriteLine("\nHow many days would you like to calculate?\n>");
                string input = Console.ReadLine();

                if (int.TryParse(input, out days))
                {
                    if (days > 0)
                    {
                        Console.WriteLine("\nYou've entered: " + days + " days");
                        run = true;
                    }
                    else
                    {
                        Console.WriteLine("\nError: Please enter a value greater than 0");
                    }
                }

                else
                {
                    Console.WriteLine("\nError: Please enter an interger");
                }
            }
               
                return days;
           
            
        }

        //Controls the for loop for the amount of days and displays the population after each day
        public static void DisplayTotal()
        {
            decimal total = SetOrganisms();
            int days = GetDays();
            Console.WriteLine("\nDay                            Approximate Population");

            for (int i= 1; i <= days; i++ )
            {
              
                Console.WriteLine("\n" + i + "                              " + total.ToString("0.######"));
                if (i < days)
                {
                    
                    total = CalculateDailyAverage(Math.Round(total, 6));
                    
                }
               
                

            }
            

        }
            
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class Data_Entry : Form
    {
        string data;
        string newData;
    
        bool update;
       
        public Data_Entry(bool insert)
        {
            InitializeComponent();
            update = insert;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          
            
            data = textBox1.Text;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (update == false)
            {
                this.cityTableAdapter.DeleteCityQuery(data);
                this.Close();
            }
            else
            {
                EnterPopulationForm a = new EnterPopulationForm(data);
                this.Hide();
                a.ShowDialog();
                this.Close();
                
              
            }
         
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Data_Entry_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


/**
* December 8, 2019
* CSC 253
* Robert Charity
* Population Database
* This program allows you to make modifications to the Population DB table
*/

namespace FormUI
{
    public partial class PopulationForm : Form
    {
    
        public PopulationForm()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void SortBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (SortBox1.Text)
            {
                case "By Population (asc)":
                    cityTableAdapter.OrderPopulationAsc(this.populationDBDataSet.City);
                    break;

                case "By Population (desc)":
                    cityTableAdapter.OrderPopulationDesc(this.populationDBDataSet.City);
                    break;

                case "By City Name (asc)":
                    cityTableAdapter.OrderCityAsc(this.populationDBDataSet.City);
                    break;

                case "By City Name (desc)":
                    cityTableAdapter.OrderCityDesc(this.populationDBDataSet.City);
                    break;
            }
         
           
        }

        private void DataBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (DataBox.Text)
            {
                case "Total Population":
                    MessageBox.Show($"Total Population = {cityTableAdapter.TotalQuery()}");
                    break;

                case "Average Population":
                    int total = int.Parse(cityTableAdapter.TotalQuery().ToString());
                    int count= int.Parse(cityTableAdapter.CountQuery().ToString());
                    double population = total / count; 
                    MessageBox.Show($"Average Population = {population}");
                    break;
                case "Highest Population":
                    population = (double)(cityTableAdapter.MaxQuery());
                   
                    MessageBox.Show($"The Highest Population = {cityTableAdapter.GetPop(population)} : {population.ToString()}");
                    break;

                case "Lowest Population":
                    population = (double)(cityTableAdapter.MinQuery());

                    MessageBox.Show($"The Lowest Population = {cityTableAdapter.GetPop(population)} : {population.ToString()}");
                    break;


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Data_Entry a = new Data_Entry(true);
            a.ShowDialog();
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Data_Entry a = new Data_Entry(false);
            a.ShowDialog();
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string city= Interaction.InputBox("What city would you like to change?");
            string newCityName= Interaction.InputBox("Enter the new city name");
            double population = double.Parse(Interaction.InputBox("Enter the new population"));
            cityTableAdapter.UpdateCityQuery(newCityName, population, city);
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }
    }
}

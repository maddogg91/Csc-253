﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class EnterPopulationForm : Form
    {
        string data;
        string newData;
        double population;
        bool update;

        public EnterPopulationForm(string storedData)
        {
            data= storedData;
            InitializeComponent();

        }

        private void EnterPopulationForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            population = double.Parse(textBox1.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                this.cityTableAdapter.InsertQuery(data, population);
                this.Close();
            
         
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }
    }
}
